# Offline C&W L2 Residual CNN simulation — real user photos

This is a **saved-image robustness experiment** for the same 64×64 TensorFlow/Keras Residual CNN used in your traffic-sign project. It does **not** change a live camera, drone, vehicle, or physical sign. It does **not** include pretrained weights or invented measurements.

## What is included

- `C_W_L2_Real_Photos_Colab.ipynb`: Google Colab instructions and evaluation runner.
- `cw_l2_offline.py`: actual Carlini–Wagner L2 optimization, predictions, metrics and plots.
- `original_photos/`: your seven uploaded images, unchanged.
- `sign_crops/`: six sign crops used for the experiment; two Stop, two 35 mph, and two 45 mph.
- `photo_manifest.json`: image labels and crop coordinates.

**Note:** `IMG_2686.jpeg` includes a partially cut-off sign and is intentionally excluded from the 6-photo quantitative evaluation; its original is still included. The two newest photographs show Stop signs under different low-light conditions. All labels come from visually inspecting your photos.

## Run in Google Colab

1. Open `C_W_L2_Real_Photos_Colab.ipynb` in Google Colab.
2. Select **Runtime → Run all**.
3. When prompted, upload **`cw_l2_photo_simulation.zip`**, **`residual_cnn_traffic_signs.keras`**, and **`residual_classes.json`**.
4. The `.keras` model and class JSON must be produced by your earlier **`Residual_CNN_80pct_Results_Colab.ipynb`** training notebook. If you don't have them, train/download them first.
5. The notebook runs C&W L2 on the six saved sign crops and downloads `cw_measured_results.zip`.

## What the results mean

- **Clean prediction**: classifier's top class before optimization.
- **Attacked prediction**: top class after the C&W digital-image test.
- **Confidence change**: after minus before probability for the actual sign class.
- **Clean accuracy**: how many of six signs were initially correctly classified.
- **Attacked accuracy**: how many were correctly classified after the digital test.
- **Attack success rate**: `successful changes / initially correct photos`, not `successful changes / all photos`.
- **Distortion amount**: pixel-space L2 norm plus mean squared error and PSNR.

Output files: `cw_summary.json`, `cw_individual_results.csv`, `cw_comparison.png`, `cw_accuracy_chart.png`, and `adversarial_test_crops/`.

**Research caveat:** Six photos from similar conditions are too few to establish an 80% benchmark or generalize to the live camera. Use the dataset held-out split for full accuracy estimates and treat these as case studies.

## Optional local command

```bash
python -m pip install -r requirements.txt
python cw_l2_offline.py --model residual_cnn_traffic_signs.keras --classes residual_classes.json
```

## Added Stop-sign photos

- `81535281429__DAAA0DED-2963-45D3-ADD5-831097CC9D88.jpeg`: close-up Stop sign at dusk.
- `IMG_0045.jpeg`: wider Stop sign view at dusk with bright streetlight glare.

Both full photos are kept unchanged in `original_photos/`; their sign crops are in `sign_crops/`. All six sign crops participate in the offline C&W evaluation. These are **six photos, not a statistically reliable test set**. The Stop images are from a similar scene and not independent examples of all conditions.
