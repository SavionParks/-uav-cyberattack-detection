"""Run a strictly offline, untargeted Carlini-Wagner L2 robustness evaluation on saved sign crops.

Requires a user-trained TensorFlow/Keras Residual CNN and matching class-name JSON.
No camera control, video modification, physical sign changes, or deployment.
"""

import argparse
import csv
import json
import math
from pathlib import Path

import numpy as np
import matplotlib.pyplot as plt
from PIL import Image
import tensorflow as tf


def read_image(path, size=(64, 64)):
    with Image.open(path) as im:
        rgb = im.convert('RGB').resize(size, Image.Resampling.BILINEAR)
        return np.asarray(rgb, dtype=np.float32) / 255.0


def scores_from_model(model, images):
    scores = model(images, training=False)
    # The repository's Residual CNN ends with a softmax. Use log probabilities
    # for the Carlini-Wagner margin, which preserves relative class margins.
    scores = tf.clip_by_value(scores, 1e-8, 1.0)
    return tf.math.log(scores)


def cw_l2_untargeted(model, clean, label_idx, steps=160,
                     binary_steps=4, learning_rate=0.018, c_start=0.02,
                     confidence_margin=0.0):
    """Find minimal-L2 misclassification via per-image CW L2 optimization.

    Evaluates only a static in-memory test crop. Does not change the original.
    Returns best successful candidate; if none, returns last optimized candidate.
    """
    clean = np.asarray(clean, np.float32)
    if clean.shape != (64, 64, 3):
        raise ValueError(f'Unexpected crop shape: {clean.shape}; expected (64,64,3)')

    clean_batch = tf.constant(clean[None, ...])
    # tanh inverse maps the valid input [0,1] into an unconstrained variable.
    bounded = np.clip(clean[None, ...], 1e-6, 1.0-1e-6)
    initial_w = tf.atanh(tf.constant((2.0*bounded - 1.0)*0.999999, tf.float32))
    lower, upper = 0.0, float('inf')
    c = float(c_start)

    best_success = None
    best_l2sq = float('inf')
    last_candidate = clean.copy()

    for _ in range(binary_steps):
        w = tf.Variable(initial_w)
        optimizer = tf.keras.optimizers.Adam(learning_rate=learning_rate)
        found_this_c = False

        for _ in range(steps):
            with tf.GradientTape() as tape:
                candidate = 0.5 * (tf.tanh(w) + 1.0)
                logits = scores_from_model(model, candidate)
                true = logits[:, label_idx]
                nontrue = tf.concat(
                    [logits[:, :label_idx], logits[:, label_idx+1:]], axis=1
                )
                highest_other = tf.reduce_max(nontrue, axis=1)
                # For untargeted CW, the penalty vanishes after misclassification.
                margin = tf.nn.relu(true - highest_other + confidence_margin)
                l2sq = tf.reduce_sum(tf.square(candidate - clean_batch), axis=[1,2,3])
                loss = tf.reduce_mean(l2sq + c * margin)

            grad = tape.gradient(loss, w)
            if grad is None:
                raise RuntimeError('No gradient through the loaded model. Ensure it is differentiable.')
            optimizer.apply_gradients([(grad, w)])

            current = (0.5 * (tf.tanh(w) + 1.0)).numpy()[0]
            last_candidate = current
            probs = model(current[None, ...], training=False).numpy()[0]
            pred = int(np.argmax(probs))
            if pred != label_idx:
                found_this_c = True
                candidate_l2sq = float(np.sum((current - clean)**2))
                if candidate_l2sq < best_l2sq:
                    best_l2sq = candidate_l2sq
                    best_success = current.copy()

        if found_this_c:
            upper = min(upper, c)
        else:
            lower = max(lower, c)

        if math.isfinite(upper):
            c = (lower + upper) / 2.0
        else:
            c *= 10.0

    return np.clip(best_success if best_success is not None else last_candidate, 0.0, 1.0)


def main():
    ap = argparse.ArgumentParser(description='Offline Residual CNN C&W L2 robustness test')
    ap.add_argument('--model', required=True, help='Trained .keras model produced by the training notebook')
    ap.add_argument('--classes', required=True, help='Matching residual_classes.json file')
    ap.add_argument('--manifest', default='photo_manifest.json')
    ap.add_argument('--output', default='cw_results')
    ap.add_argument('--steps', type=int, default=160)
    ap.add_argument('--binary-steps', type=int, default=4)
    ap.add_argument('--learning-rate', type=float, default=0.018)
    ap.add_argument('--c-start', type=float, default=0.02)
    args = ap.parse_args()

    if args.steps < 1 or args.binary_steps < 1 or args.c_start <= 0:
        ap.error('--steps/--binary-steps must be positive and --c-start > 0')

    base = Path(__file__).resolve().parent
    manifest_path = Path(args.manifest)
    if not manifest_path.is_file():
        manifest_path = base / args.manifest
    with manifest_path.open('r', encoding='utf-8') as f:
        manifest = json.load(f)

    model_path = Path(args.model)
    classes_path = Path(args.classes)
    if not model_path.is_file() or not classes_path.is_file():
        raise FileNotFoundError(
            'Missing trained .keras model or class JSON. Train Residual_CNN_80pct_Results_Colab.ipynb '
            'and upload the exported weights and class map before running this evaluation.'
        )

    with classes_path.open('r', encoding='utf-8') as f:
        class_names = json.load(f)
    if len(set(class_names)) != len(class_names) or len(class_names) < 2:
        raise ValueError('The class JSON must contain two or more unique names.')

    model = tf.keras.models.load_model(str(model_path), compile=False)
    if model.output_shape[-1] != len(class_names):
        raise ValueError('Output head and class-name JSON disagree.')
    if model.input_shape[1:] != (64, 64, 3):
        raise ValueError('Model must have expected input shape (64,64,3).')

    # Check that the model output is normalized probabilities.
    dummy = model(tf.zeros((1,64,64,3)), training=False).numpy()
    if not np.allclose(dummy.sum(axis=1), 1.0, atol=0.02):
        raise ValueError('Expected a model ending in softmax probabilities.')

    output = Path(args.output)
    output.mkdir(parents=True, exist_ok=True)
    adv_folder = output/'adversarial_test_crops'; adv_folder.mkdir(exist_ok=True)
    rows = []; visual_rows = []

    for item in manifest:
        path = base / item['image']
        label = item['true_label']
        if label not in class_names:
            raise ValueError(f"{label} missing from provided class_names: {class_names}")
        y = class_names.index(label)
        clean = read_image(path)
        clean_probs = model(clean[None,...], training=False).numpy()[0]
        clean_idx = int(np.argmax(clean_probs))
        clean_correct = (clean_idx == y)

        if clean_correct:
            adv = cw_l2_untargeted(
                model, clean, y, steps=args.steps, binary_steps=args.binary_steps,
                learning_rate=args.learning_rate, c_start=args.c_start
            )
            tested = True
        else:
            # Not eligible for attack success: it was wrong before perturbation.
            # Keep a copy unchanged rather than misreporting a baseline failure.
            adv = clean.copy()
            tested = False
        attack_probs = model(adv[None,...], training=False).numpy()[0]
        adv_idx = int(np.argmax(attack_probs))
        successful = bool(clean_correct and (adv_idx != y))

        diff = adv - clean
        mse = float(np.mean(diff ** 2))
        l2 = float(np.linalg.norm(diff.reshape(-1), ord=2))
        psnr = float('inf') if mse == 0 else float(10.0 * math.log10(1.0 / mse))
        out_name = Path(item['image']).stem + '_cw_l2.png'
        Image.fromarray(np.uint8(np.round(adv * 255))).save(adv_folder/out_name)

        row = {
            'source': item['source'], 'image': item['image'], 'true_label': label,
            'clean_prediction': class_names[clean_idx],
            'clean_prediction_confidence': round(float(clean_probs[clean_idx]), 6),
            'clean_true_class_confidence': round(float(clean_probs[y]), 6),
            'attack_attempted': tested,
            'attacked_prediction': class_names[adv_idx],
            'attacked_prediction_confidence': round(float(attack_probs[adv_idx]), 6),
            'attacked_true_class_confidence': round(float(attack_probs[y]), 6),
            'true_class_confidence_change': round(float(attack_probs[y]-clean_probs[y]), 6),
            'initially_correct': clean_correct,
            'cw_attack_success': successful if tested else '',
            'l2_distortion': round(l2, 6),
            'mse_distortion': round(mse, 8),
            'psnr_db': round(psnr, 2) if math.isfinite(psnr) else '',
            'output_image': str(adv_folder/out_name)
        }
        rows.append(row)
        visual_rows.append((item['source'], label, clean, adv, diff, row))
        print(f"{item['source']}: true={label}; clean={row['clean_prediction']} "
              f"({row['clean_prediction_confidence']:.1%}); "
              f"after={row['attacked_prediction']} "
              f"({row['attacked_prediction_confidence']:.1%}); "
              f"attack_success={row['cw_attack_success']}; L2={l2:.3f}")

    csv_path = output/'cw_individual_results.csv'
    with csv_path.open('w', newline='', encoding='utf-8') as f:
        writer=csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        writer.writeheader();writer.writerows(rows)

    total=len(rows)
    initially_correct=sum(int(r['initially_correct']) for r in rows)
    after_correct=sum(int(r['attacked_prediction']==r['true_label']) for r in rows)
    attack_successes=sum(int(r['cw_attack_success'] is True) for r in rows)

    summary = {
        'model': model_path.name,
        'attack': 'Carlini-Wagner L2 (untargeted, offline, saved crops)',
        'images_in_evaluation':total,
        'original_photo_2686_excluded':'partial/cut-off sign; not used for quantitative accuracy',
        'clean_accuracy': initially_correct / total,
        'attacked_accuracy': after_correct / total,
        'initially_correct_count':initially_correct,
        'cw_success_count':attack_successes,
        'attack_success_rate_on_initially_correct': (
            attack_successes / initially_correct if initially_correct else None
        ),
        'mean_l2_on_attempted': (
            float(np.mean([r['l2_distortion'] for r in rows if r['attack_attempted']]))
            if initially_correct else None
        ),
        'notes':[
            'Four real-world photos are too few for statistically reliable model accuracy.',
            'Two photos show 35 mph and two show 45 mph; no Stop photo in this batch.',
            'A photo misclassified before attack is not counted as an attack success.',
            'Results depend on supplied model weights and may show zero successful attacks.',
            'This does not assess any physical-world or live-camera attack.'
        ]
    }
    (output/'cw_summary.json').write_text(json.dumps(summary, indent=2), encoding='utf-8')

    n=len(visual_rows)
    fig, axes=plt.subplots(n,3,figsize=(11,3.2*n),squeeze=False)
    for row_i, (source, label, clean, adv, diff, row) in enumerate(visual_rows):
        visible=np.clip(0.5 + diff/(2*max(np.max(np.abs(diff)),1e-6)), 0,1)
        images=[clean,visible,adv]
        titles=[f'Original: {label}\nPred: {row["clean_prediction"]}',
                f'Visible difference\nL2={row["l2_distortion"]:.3f}',
                f'CW offline result\nPred: {row["attacked_prediction"]}']
        for ax,im,title in zip(axes[row_i],images,titles):
            ax.imshow(im); ax.set_title(title, fontsize=10); ax.axis('off')
        axes[row_i][0].set_ylabel(source,fontsize=9)
    fig.suptitle('Offline Carlini-Wagner L2 robustness test — measured results',fontsize=14)
    plt.tight_layout(rect=[0,0,1,0.97]);fig.savefig(output/'cw_comparison.png',dpi=160,bbox_inches='tight');plt.close(fig)

    fig, ax=plt.subplots(figsize=(7,4))
    ax.bar(['Clean accuracy','After C&W L2'],[100*summary['clean_accuracy'],100*summary['attacked_accuracy']])
    ax.set_ylim(0,100);ax.set_ylabel('Accuracy on four provided photos (%)')
    ax.set_title('Measured classification accuracy — offline only')
    fig.tight_layout();fig.savefig(output/'cw_accuracy_chart.png',dpi=180);plt.close(fig)

    print('\nSUMMARY')
    print('Clean accuracy: {:.1%}'.format(summary['clean_accuracy']))
    print('Accuracy after C&W: {:.1%}'.format(summary['attacked_accuracy']))
    if summary['attack_success_rate_on_initially_correct'] is None:
        print('Attack success rate: N/A (no initially correct predictions)')
    else:
        print('Attack success rate among initially correct: {:.1%} ({}/{})'.format(
            summary['attack_success_rate_on_initially_correct'],
            attack_successes,initially_correct
        ))
    print('Results folder:',output.resolve())

if __name__=='__main__':
    main()
